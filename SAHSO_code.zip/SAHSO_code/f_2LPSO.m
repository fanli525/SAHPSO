%function [fy,fNFE,T1,fdv]=f_2LPSO(fun,D,lb,ub)
 clc;clear all;close all;set(0,'defaultfigurecolor','w');lb=-5;ub=5;D=30; fun=@Rastrigin;%GriewankAckleyRosenbrock(x)benchmark_func(x,10)Ellipsoid(x)(x)rastrigin_rotSphere
T0=cputime;
Dat.myFN =fun;
Dat.designspace = [lb;ub]*ones(1,D);   % lower bound % upper bound
Dat.ndv = D;
bound=Dat.designspace;
vbound(2,:)=0.2*(bound(2,:)-bound(1,:));vbound(1,:)=-vbound(2,:);

%% ��ʼ���������create DOE
if D<=100;  k=100;% ������Ŀ
else;k=2*D;end
  
Dat.npoints =k;Doe=@DOELHS ;%@DOEOLHS
[Xtrain Ytrain]=my_initial(Dat,Doe);
NFE=k;
%% ��ʼ����Ⱥ��Ŀ
[val ind ]=sort(Ytrain);

N=40;
pop=Xtrain(ind(1:N),:);fpop=Ytrain(ind(1:N));pbest=pop;   fpbest=fpop;

gbest=Xtrain(ind(1),:);fgbest=fpbest(1);
Dat.npoints =N;
[u,~]=my_initial(Dat,Doe);
u=0.25*u; v=u;         %0.5*pop��ʼ�ٶ�
w=0.729;   c1=1.491;  c2=1.491;wmax=0.729;wmin=.2;
%%
fNFE(1:NFE)=fgbest;Samp=[Xtrain];YS=[Ytrain];fdv(1:NFE)=Diversity(pop,bound(1,:),bound(2,:));
maxNFE=1000;t=1;
dlta=min(sqrt(0.001^2*D),0.00005*sqrt(Dat.ndv)*min(Dat.designspace(2,:)-Dat.designspace(1,:)));

t1=0.4*maxNFE   ;%��ʼȫ��ʹ��SPSO��ʱ��
%% ��ʼ����
while NFE< maxNFE

    srgtOPT=srgtsRBFSetOptions(Samp,YS, @my_rbfbuild, [],'CUB', 0.0002,1);
    srgtSRGT = srgtsRBFFit(srgtOPT);
    L2 =@(x)my_rbfpredict(srgtSRGT.RBF_Model, srgtSRGT.P, x);
    FE=3000;
    options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',FE,'TolFun',1e-8,'GradObj','off'); % run interior-point algorithm
    L=Dat.designspace(1,:);U=Dat.designspace(2,:);
    if isnan(L2(gbest))==0
        x= fmincon(L2,gbest,[],[],[],[],L,U,[],options);
        dx=min(sqrt(sum((repmat(x,size(Samp,1),1)-Samp).^2,2)));
        if dx>dlta
            fx=Dat.myFN(x);    Samp=[ Samp;x]; YS=[YS;fx];
            NFE=NFE+1;  fNFE(NFE)=min(YS);fdv(NFE)=Diversity(pop,bound(1,:),bound(2,:));
            if fx<fgbest
                fgbest= fx; gbest=x;
            end
        end
    end
    %% ̽������
    if     NFE<t1
%         sprintf('lpso')
        for i=1:N
            A = 1:N;A(i)=[];  j = A(randi(N-1));
            Step = pop(i,:) - pop(j,:);
            if fpop(j)< fpop(i)
                Step = -Step;
            end
            newpop(i,:)= pop(i,:) + rand(1,D).*Step;
            for j=1:D
                if newpop(i,j)<bound(1,j)
                    newpop(i,j)=bound(1,j);
                end
                if  newpop(i,j)>bound(2,j)
                    newpop(i,j)=bound(2,j);
                end
            end
        end
    end
    
    if    NFE>t1
%         sprintf('spso')
        %% ��������������
        for i=1:N
            for d=1:D
                v(i,d)=w*v(i,d)+rand*c1*(gbest(d)-pop(i,d))+rand*c2*(pbest(i,d)-pop(i,d));%
            end
            for j=1:D
                if  v(i,j)<vbound(1,j)
                    v(i,j)=vbound(1,j);
                end
                if  v(i,j)>vbound(2,j)
                    v(i,j)=vbound(2,j);
                end
            end
            pop1(i,:)=pop(i,:)+v(i,:);
            for j=1:D
                if pop1(i,j)<bound(1,j)
                    pop1(i,j)=bound(1,j);
                end
                if  pop1(i,j)>bound(2,j)
                    pop1(i,j)=bound(2,j);
                end
            end
            newpop(i,:)=pop1(i,:);
            pop(i,:)=pop1(i,:);
        end
    end
    
    %% ���¸��塢ȫ������
    srgtOPT=srgtsRBFSetOptions(Samp,YS, @my_rbfbuild, [], 'CUB',0.0002,1);
    srgtSRGT = srgtsRBFFit(srgtOPT);
    predy= my_rbfpredict(srgtSRGT.RBF_Model, srgtSRGT.P, newpop);
     tep=0;tep1=0;Apop=[];
    if NFE<t1
        for i=1:N
            d=min(sqrt(sum((repmat(newpop(i,:),size(Samp,1),1)-Samp).^2,2)));
            if  predy(i)<fpop(i) & d>dlta
                tep= tep+1;Apop=[Apop;i];
                fnewpop(i)=Dat.myFN( newpop(i,:));
                Samp=[ Samp; newpop(i,:)]; YS=[YS;fnewpop(i)];
                NFE=NFE+1; fNFE(NFE)=min(YS);fdv(NFE)=Diversity(pop,bound(1,:),bound(2,:));
                if fnewpop(i)<fpop(i)
                    pop(i,:) = newpop(i,:);fpop(i)=fnewpop(i);tep1= tep1+1;
                end
                if fpop(i)<fpbest(i)
                    pbest(i,:)=pop(i,:);fpbest(i)= fpop(i);
                end
                if fpbest(i)<fgbest
                    gbest= pbest(i,:);fgbest=fpbest(i);
                end
            end
        end
         if tep==0
            [val,ind]=min(predy);
            fnew=Dat.myFN( newpop(ind,:));
            Samp=[ Samp; newpop(ind,:)]; YS=[YS;fnew];
            NFE=NFE+1; fNFE(NFE)=min(YS);fdv(NFE)=Diversity(pop,bound(1,:),bound(2,:));
            if fnew<fpop(ind)
                pop(ind,:) = newpop(ind,:);fpop(ind)=fnew;
            end
            if fpop(ind)<fpbest(ind)
                pbest(ind,:)= pop(ind,:);fpbest(ind)=fpop(ind);
            end
            if fnew<fgbest
                gbest= newpop(ind,:);fgbest=fnew;
            end
        end
    else
        Ig=fpbest-predy;
        [val,ind]=sort(Ig,'descend');
        a1=find(val>0);
        Is=[];
        if length(a1)>0
              a3=a1(end);
            Ipop=ind(1:a3);
            Is=length(Ipop);
        end
        if Is>0
            Is1=Is/3;
            for i1=1:Is1
                i=Ipop(i1);
                d=min(sqrt(sum((repmat(newpop(i,:),size(Samp,1),1)-Samp).^2,2)));
                if  predy(i)<fpbest(i) & d>dlta
                    fnewpop(i)=Dat.myFN( newpop(i,:));tep= tep+1;
                    Samp=[ Samp; newpop(i,:)]; YS=[YS;fnewpop(i)];
                    NFE=NFE+1; fNFE(NFE)=min(YS);fdv(NFE)=Diversity(pop,bound(1,:),bound(2,:));
                    if fnewpop(i)<fpop(i)
                        pop(i,:) = newpop(i,:);fpop(i)=fnewpop(i);
                    end
                    if fpop(i)<fpbest(i)
                        pbest(i,:)=pop(i,:);fpbest(i)= fpop(i);tep1= tep1+1;
                    end
                    if fpbest(i)<fgbest
                        gbest= pbest(i,:);fgbest=fpbest(i);
                    end
                end
            end
            if Is1<1
                [val,ind]=min(predy);
                fnew=Dat.myFN( newpop(ind,:));
                Samp=[ Samp; newpop(ind,:)]; YS=[YS;fnew];
                NFE=NFE+1; fNFE(NFE)=min(YS);fdv(NFE)=Diversity(pop,bound(1,:),bound(2,:));
                if fnew<fpop(ind)
                    pop(ind,:) = newpop(ind,:);fpop(ind)=fnew;
                end
                if fpop(ind)<fpbest(ind)
                    pbest(ind,:)= pop(ind,:);fpbest(ind)=fpop(ind);
                end
                if fnew<fgbest
                    gbest= newpop(ind,:);fgbest=fnew;
                end
            end
         end
    end
 t=t+1; NFE
end
fy=fgbest;
T1=cputime-T0;

%Rosenbrock model  ��Сֵf(420.9687,420.9687)=0
function y=Schwefel(x)
[m,k]=size(x);
for i=1:m
    d=0;
    for j=1:k
        d=d+x(i,j)*sin(sqrt(abs(x(i,j))));
    end
    y(i)=k*418.9829-d;
end
y=y';

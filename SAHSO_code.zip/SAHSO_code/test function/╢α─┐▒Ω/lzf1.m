function PopObj =lzf1(X)

[N,D] = size(X);
J1    = 3 : 2 : D;
J2    = 2 : 2 : D;
PopObj(:,1) = X(:,1)         + 2*mean((X(:,J1)-repmat(X(:,1),1,length(J1)).^repmat((1+3*(J1-2)/(D-2))/2,N,1)).^2,2);
PopObj(:,2) = 1-sqrt(X(:,1)) + 2*mean((X(:,J2)-repmat(X(:,1),1,length(J2)).^repmat((1+3*(J2-2)/(D-2))/2,N,1)).^2,2);
PopObj =PopObj';

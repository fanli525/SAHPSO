function PopObj =dtlz7(PopDec,M)
PopObj          = zeros(size(PopDec,1),M);
g               = 1+9*mean(PopDec(:,M:end),2);
PopObj(:,1:M-1) = PopDec(:,1:M-1);
PopObj(:,M)     = (1+g).*(M-sum(PopObj(:,1:M-1)./(1+repmat(g,1,M-1)).*(1+sin(3*pi.*PopObj(:,1:M-1))),2));

PopObj =PopObj';
function P = PF_dtlz1(obj,N)

P = UniformPoint(N,obj)/2;
end
function f=KNO1(x)
% x=[x1 x2];[0 3]
% PS: x1+x2=4.4116;
for i=1:size(x,1)
    r1=sin(5/(2*(x(i,1)+x(i,2))^2));
    r2=sin(4*(x(i,1)+x(i,2)));
    r3=sin(2*(x(i,1)+x(i,2))+2);
    fai=pi/(12*(x(i,1)-x(i,2)+3));
        fai=pi*(x(i,1)-x(i,2)+3)/(12);

    r=9-(3*r1+3*r2+5*r3);
    f(i,1)=20-r*cos(fai);
    f(i,2)=20-r*sin(fai);
end
f=f';

% c = x[0] + x[1];
% 
% f = 20 - (11 + 3 * sin((5 * c) * (0.5 * c)) + 3 * sin(4 * c) + 5 * sin(2 * c + 2));
% // f = 20*(1-(myabs(c-3.0)/3.0));
% 
% g = (PI / 2.0) * (x[0] - x[1] + 3.0) / 6.0;
% 
% y[0] = 20 - (f * cos(g));
% y[1] = 20 - (f * sin(g));



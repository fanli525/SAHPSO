function PopObj =lzf2(X)

[N,D] = size(X);
J1    = 3 : 2 : D;
J2    = 2 : 2 : D;
PopObj(:,1) = X(:,1)         + 2*mean((X(:,J1)-sin(repmat(6*pi*X(:,1),1,length(J1))+repmat(J1*pi/D,N,1))).^2,2);
PopObj(:,2) = 1-sqrt(X(:,1)) + 2*mean((X(:,J2)-sin(repmat(6*pi*X(:,1),1,length(J2))+repmat(J2*pi/D,N,1))).^2,2);

PopObj =PopObj';

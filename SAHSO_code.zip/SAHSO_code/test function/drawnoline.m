function drawnoline
 set(0,'defaultfigurecolor','w') 

 x0=0:0.01:1;
y0=noline(x0); 
x=0:0.01:5;
y= noline(x); 

figure (1)
plot(x0,y0,'linewidth',2)
set(gca,'FontSize',12)
set(gca,'linewidth',1.5);
figure (2)
plot(x,y,'linewidth',2)
set(gca,'FontSize',12)
set(gca,'linewidth',1.5);
function y =Rastrigin(x)% ���Rastriginf(0)=0[ -5.12 5.12]
[m,n]=size(x);
% x=x-2;
for i=1:m
    d=0;
    for j=1:n
        d=d+x(i,j).^ 2 - 10 * cos(2*pi*x(i,j)) + 10;
    end
    y(i)=d;
end
y=y';

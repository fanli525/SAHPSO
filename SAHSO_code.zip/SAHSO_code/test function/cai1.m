function y = cai1(x)
a=sin(x+0.5);
y =0.5*sin(4*pi*a)+(x+0.5).^2/3;


return
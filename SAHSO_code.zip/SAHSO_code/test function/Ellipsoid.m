function y =Ellipsoid(x)
[m,n]=size(x);
for i=1:m
    d=0;
    for j=1:n
    d =d+j*x(i,j).^2;
    end
    y(i)=d;
end
y=y';
return








    f = sum(x .* x .* [1:numel(x)]');
end

function y = Griewank(x)
% ���Griewank f(0)=0
[m,n]=size(x);
for i=1:m
    d=1;
    for j=1:n
        d=d*cos(x(i,j)/sqrt(j));
    end
    d=-d;
    for j=1:n
        d=d+1/4000*(x(i,j).^2);
    end
    d=d+1;
    y(i)=d;
end
y=y';
%Rosenbrock model  ��Сֵf(1,1)=0
function y=Rosenbrock(x)
[m,k]=size(x);
for i=1:m
    d=0;
    for j=1:k-1
        d=d+100*(x(i,j+1)-(x(i,j))^2)^2+(x(i,j)-1)^2;
    end
    y(i)=d;
end
y=y';

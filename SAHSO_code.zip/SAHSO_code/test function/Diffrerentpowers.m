%SUM OF DIFFERENT POWERS FUNCTION ��Сֵf(0,0)=0  x[-1,1]
function y=Diffrerentpowers(x)
[m,k]=size(x);
for i=1:m
    d=0;
    for j=1:k
        d=d+(abs(x(i,j)))^(j+1);
    end
    y(i)=d;
end
y=y';
function y =m_Rastrigin(x)% ���Rastriginf(0)=0[ -5.12 5.12]
[m,n]=size(x);
 %c=[1 0.2 40; 3 21  3.9; 8.1 2.3 4.3 ]; 22
x=(x-5)*0.2;
for i=1:m
    d=0;
    for j=1:n
        d=d+x(i,j).^ 2 - 10 * cos(2*pi*x(i,j)) + 10;
    end
    y(i)=d;
end
y=y';
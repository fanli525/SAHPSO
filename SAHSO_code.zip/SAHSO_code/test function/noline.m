function y=noline(x)
y=(1-exp(-2*sqrt(x)))+6*x.*exp(-7*x).*sin(10*x)-0.2*exp(-2000*(x-0.25).^2)+... 
    60*(min(0,abs(x-0.14)-0.08)).^2.*(log(x+0.2)+1.5*(sin(85*x)).^2);
y=-y;
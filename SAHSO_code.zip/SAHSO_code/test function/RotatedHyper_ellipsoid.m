function y =RotatedHyper_ellipsoid(x)% ���Rastriginf(0)=0[ -65.  65. ]
[m,n]=size(x);
for k=1:m
    d=0;
    for i=1:n
        for j=1:i
        d=d+x(k,j).^ 2;
        end
    end
    y(k)=d;
end
y=y';
function y=Ackley(x)
[m,n]=size(x);
for i=1:m
     a=-0.2*sqrt(sum(x(i,:).^2)/n);
    b=sum(cos(2*pi*x(i,:)))/n;
    d=-20.*exp(a)-exp(b)+20+ exp(1);
    y(i) =d;
end
y=y';

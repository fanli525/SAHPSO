function y = L_cai1(x)
a=sin(x+0.5);
y =0.5*sin(4*pi*a)+(x+0.5).^2/3;
y =0.8*y-0.1*x.^2-0.4*x-0.1;

return
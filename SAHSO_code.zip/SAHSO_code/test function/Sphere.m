function y = Sphere(x)
[m,n]=size(x);
for i=1:m
    y(i) =sum(x(i,:).^2);
end
y=y';
return
% Generate Kriging options structure
opts = Kriging.getDefaultOptions();
opts.hpBounds = [lb ; ub]; % hyperparameter optimization bounds
% configure the SQPLab optimization algorithm (included)
opts.hpOptimizer = SQPLabOptimizer( inDim, 1 );
% create and fit the Kriging model
k = Kriging( opts, hyperparameters0, 'regpoly2', @corrgauss );
k = k.fit( samples, values );
k = k.cleanup(); % optional: only needed for very large datasets
% k represents the approximation and can now be used, e.g.,
[y mse] = k.predict( [1 2] )

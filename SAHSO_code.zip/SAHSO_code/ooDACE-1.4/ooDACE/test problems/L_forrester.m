function y =L_forrester(x)

y =((x.*6-2).^2).*sin((x.*6-2).*2);
y=0.5*y+10*(x-0.5)-5;

return

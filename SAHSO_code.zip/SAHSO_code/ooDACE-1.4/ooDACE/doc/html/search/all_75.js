var searchData=
[
  ['updatemodel',['updateModel',['../class_basic_gaussian_process.html#ab0b273aed79e41eb3b96df1ecdc761bf',1,'BasicGaussianProcess']]],
  ['updatemodel_2em',['updateModel.m',['../update_model_8m.html',1,'']]],
  ['updateregression',['updateRegression',['../class_basic_gaussian_process.html#a05379f1addc3495b113848b2a64be11b',1,'BasicGaussianProcess']]],
  ['updateregression_2em',['updateRegression.m',['../update_regression_8m.html',1,'']]],
  ['updatestochasticprocess',['updateStochasticProcess',['../class_basic_gaussian_process.html#a180189336eeba0a3987b0036959d6af8',1,'BasicGaussianProcess']]],
  ['updatestochasticprocess_2em',['updateStochasticProcess.m',['../update_stochastic_process_8m.html',1,'']]]
];

var searchData=
[
  ['extrinsiccorrelationmatrix',['extrinsicCorrelationMatrix',['../class_basic_gaussian_process.html#ad0dfbcfe7185eabb54cf546c5c52624b',1,'BasicGaussianProcess::extrinsicCorrelationMatrix()'],['../class_co_kriging.html#ad0dfbcfe7185eabb54cf546c5c52624b',1,'CoKriging::extrinsicCorrelationMatrix()']]],
  ['extrinsiccorrelationmatrix_2em',['extrinsicCorrelationMatrix.m',['../@_basic_gaussian_process_2extrinsic_correlation_matrix_8m.html',1,'']]],
  ['extrinsiccorrelationmatrix_2em',['extrinsicCorrelationMatrix.m',['../@_co_kriging_2extrinsic_correlation_matrix_8m.html',1,'']]]
];

var searchData=
[
  ['optimizer',['Optimizer',['../class_optimizer.html',1,'']]]
];

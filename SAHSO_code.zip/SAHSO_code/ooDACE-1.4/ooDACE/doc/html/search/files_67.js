var searchData=
[
  ['generatedatasets_2em',['generateDatasets.m',['../generate_datasets_8m.html',1,'']]],
  ['generatedegrees_2em',['generateDegrees.m',['../generate_degrees_8m.html',1,'']]],
  ['getbounds_2em',['getBounds.m',['../get_bounds_8m.html',1,'']]],
  ['getexpression_2em',['getExpression.m',['../@_basic_gaussian_process_2get_expression_8m.html',1,'']]],
  ['getexpression_2em',['getExpression.m',['../@_kriging_2get_expression_8m.html',1,'']]],
  ['gethint_2em',['getHint.m',['../get_hint_8m.html',1,'']]],
  ['getinitialpopulation_2em',['getInitialPopulation.m',['../get_initial_population_8m.html',1,'']]],
  ['getinputdimension_2em',['getInputDimension.m',['../get_input_dimension_8m.html',1,'']]],
  ['getoutputdimension_2em',['getOutputDimension.m',['../get_output_dimension_8m.html',1,'']]],
  ['getpopulationsize_2em',['getPopulationSize.m',['../@_matlab_g_a_2get_population_size_8m.html',1,'']]],
  ['getpopulationsize_2em',['getPopulationSize.m',['../@_optimizer_2get_population_size_8m.html',1,'']]]
];

var searchData=
[
  ['cfix',['cfix',['../cfix_8m.html#a6487abc08b56d2d72239cb336ae48d51',1,'cfix.m']]],
  ['cleanup',['cleanup',['../class_basic_gaussian_process.html#acc3f96a4512c7485e5556578d9ef28fb',1,'BasicGaussianProcess']]],
  ['cmp_5fcombinedrelative',['cmp_combinedRelative',['../run_regression_tests_8m.html#a8ef04b69109b5edc16f799cb684c10b9',1,'runRegressionTests.m']]],
  ['cokriging',['CoKriging',['../class_co_kriging.html#a58e74146a1f787f32c0c54d5dd18e926',1,'CoKriging']]],
  ['corrcubic',['corrcubic',['../corrcubic_8m.html#a74c2282a4625f7b978f6beea3e886aae',1,'corrcubic.m']]],
  ['correlationfunction',['correlationFunction',['../class_basic_gaussian_process.html#a3631758c3900549a78e1a81062322da8',1,'BasicGaussianProcess::correlationFunction()'],['../class_co_kriging.html#a02909c584b65750e38dc318f6ea4b501',1,'CoKriging::correlationFunction()']]],
  ['correxp',['correxp',['../correxp_8m.html#a14a294498b79b7636206a4573653d78c',1,'correxp.m']]],
  ['corrgauss',['corrgauss',['../corrgauss_8m.html#af3c2036ca67ca8b7a970cc490150ca69',1,'corrgauss.m']]],
  ['corrgaussp',['corrgaussp',['../corrgaussp_8m.html#ae87ac4ab8140d5b94827c8cad30f089b',1,'corrgaussp.m']]],
  ['corrlin',['corrlin',['../corrlin_8m.html#ab8dd12530e57354c80cd8158a81aa252',1,'corrlin.m']]],
  ['corrmatern32',['corrmatern32',['../corrmatern32_8m.html#a4c7d7de9fe756b6b1d8d441cc55f9b82',1,'corrmatern32.m']]],
  ['corrmatern32_5fiso',['corrmatern32_iso',['../corrmatern32__iso_8m.html#a2291872251a0d5d2dcf0f5ca5d8f2db9',1,'corrmatern32_iso.m']]],
  ['corrmatern32_5fvariance',['corrmatern32_variance',['../corrmatern32__variance_8m.html#a857398c062a2bfff547dbd8465bde18c',1,'corrmatern32_variance(var hp, var d):&#160;corrmatern32_variance.m'],['../covmatern32_8m.html#a857398c062a2bfff547dbd8465bde18c',1,'corrmatern32_variance(var hp, var d):&#160;covmatern32.m']]],
  ['corrmatern32iso',['corrmatern32iso',['../corrmatern32iso_8m.html#a7af632b0a9e027e8aa981ec54be6bf84',1,'corrmatern32iso.m']]],
  ['corrmatern52',['corrmatern52',['../corrmatern52_8m.html#ac817ddc899c3a6429c2aec6684689087',1,'corrmatern52.m']]],
  ['corrspherical',['corrspherical',['../corrspherical_8m.html#a6b79da6b31eefeec77e007eaf15e6a9d',1,'corrspherical.m']]],
  ['corrspline',['corrspline',['../corrspline_8m.html#aa05132231e67fe75a5959a3679bdc704',1,'corrspline.m']]],
  ['cvpe',['cvpe',['../class_basic_gaussian_process.html#a013748ab0596572131138442d8b684dd',1,'BasicGaussianProcess::cvpe()'],['../class_kriging.html#a013748ab0596572131138442d8b684dd',1,'Kriging::cvpe()']]]
];

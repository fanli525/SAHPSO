var searchData=
[
  ['dacefit',['dacefit',['../dacefit_8m.html#ab70279fbd8033a17b41b68346ac7777a',1,'dacefit.m']]],
  ['dacefit_2em',['dacefit.m',['../dacefit_8m.html',1,'']]],
  ['demo',['demo',['../demo_8m.html#a5a1927cd442e61d4db92b500132c054f',1,'demo.m']]],
  ['demo_2em',['demo.m',['../demo_8m.html',1,'']]],
  ['display',['display',['../class_basic_gaussian_process.html#a9de56d4c14e5e934fb1cbdbf87dc337f',1,'BasicGaussianProcess']]],
  ['dist',['dist',['../class_basic_gaussian_process.html#a8871762dddde8a7dbde82d6603e8782c',1,'BasicGaussianProcess']]],
  ['distidxpsi',['distIdxPsi',['../class_basic_gaussian_process.html#a8fdbf26960e1ee465687cbd1a9177082',1,'BasicGaussianProcess']]]
];

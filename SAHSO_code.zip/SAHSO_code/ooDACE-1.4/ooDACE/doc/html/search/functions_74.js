var searchData=
[
  ['tuneparameters',['tuneParameters',['../class_basic_gaussian_process.html#a048f85cd5124ba5ebb505f881ca07d9a',1,'BasicGaussianProcess']]]
];

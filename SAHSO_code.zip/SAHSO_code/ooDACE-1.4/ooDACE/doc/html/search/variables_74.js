var searchData=
[
  ['tau2',['tau2',['../class_basic_gaussian_process.html#aa9ed97eb743ac786e277270e0290c292',1,'BasicGaussianProcess']]]
];
